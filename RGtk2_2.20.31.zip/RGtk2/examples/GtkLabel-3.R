## Pressing Alt+H will activate this button
button <- gtkButtonNewWithMnemonic("_Hello")
