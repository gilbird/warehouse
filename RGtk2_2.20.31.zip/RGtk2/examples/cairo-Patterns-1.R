cr$setSourceSurface(image, x, y)
cr$getSource()$setFilter("nearest")
