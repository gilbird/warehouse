#ifndef S_GDK_IMPORTS_C
#define S_GDK_IMPORTS_C
#include <RGtk2/gdk.h>

#include <RGtk2/pangoImports.c>

#include <RGtk2/gioImports.c>

#include <RGtk2/gdkUserFuncImports.c>

#include <RGtk2/gdkClassImports.c>

#endif
