manager <- gtkRecentManagerGetDefault()
manager$addItem(file_uri)

