#ifndef S_ATK_USERFUNCS_H
#define S_ATK_USERFUNCS_H
#include <RGtk2/gobject.h>
#include <RGtk2/atk.h>


  gint
S_AtkKeySnoopFunc(AtkKeyEventStruct* s_event, gpointer s_func_data); 

#endif
