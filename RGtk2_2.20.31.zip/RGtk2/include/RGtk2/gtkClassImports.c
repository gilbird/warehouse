void
S_gtk_about_dialog_class_init(GtkAboutDialogClass * c, SEXP e)
{
  static void (*fun)(GtkAboutDialogClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkAboutDialogClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_about_dialog_class_init"));
  return(fun(c, e));
} 

void
S_gtk_accel_group_class_init(GtkAccelGroupClass * c, SEXP e)
{
  static void (*fun)(GtkAccelGroupClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkAccelGroupClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_accel_group_class_init"));
  return(fun(c, e));
} 

void
S_gtk_accel_label_class_init(GtkAccelLabelClass * c, SEXP e)
{
  static void (*fun)(GtkAccelLabelClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkAccelLabelClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_accel_label_class_init"));
  return(fun(c, e));
} 

void
S_gtk_accessible_class_init(GtkAccessibleClass * c, SEXP e)
{
  static void (*fun)(GtkAccessibleClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkAccessibleClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_accessible_class_init"));
  return(fun(c, e));
} 

void
S_gtk_action_class_init(GtkActionClass * c, SEXP e)
{
  static void (*fun)(GtkActionClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkActionClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_action_class_init"));
  return(fun(c, e));
} 

void
S_gtk_action_group_class_init(GtkActionGroupClass * c, SEXP e)
{
  static void (*fun)(GtkActionGroupClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkActionGroupClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_action_group_class_init"));
  return(fun(c, e));
} 

void
S_gtk_adjustment_class_init(GtkAdjustmentClass * c, SEXP e)
{
  static void (*fun)(GtkAdjustmentClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkAdjustmentClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_adjustment_class_init"));
  return(fun(c, e));
} 

void
S_gtk_alignment_class_init(GtkAlignmentClass * c, SEXP e)
{
  static void (*fun)(GtkAlignmentClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkAlignmentClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_alignment_class_init"));
  return(fun(c, e));
} 

void
S_gtk_arrow_class_init(GtkArrowClass * c, SEXP e)
{
  static void (*fun)(GtkArrowClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkArrowClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_arrow_class_init"));
  return(fun(c, e));
} 

void
S_gtk_aspect_frame_class_init(GtkAspectFrameClass * c, SEXP e)
{
  static void (*fun)(GtkAspectFrameClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkAspectFrameClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_aspect_frame_class_init"));
  return(fun(c, e));
} 

void
S_gtk_bin_class_init(GtkBinClass * c, SEXP e)
{
  static void (*fun)(GtkBinClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkBinClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_bin_class_init"));
  return(fun(c, e));
} 

void
S_gtk_box_class_init(GtkBoxClass * c, SEXP e)
{
  static void (*fun)(GtkBoxClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkBoxClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_box_class_init"));
  return(fun(c, e));
} 

void
S_gtk_button_class_init(GtkButtonClass * c, SEXP e)
{
  static void (*fun)(GtkButtonClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkButtonClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_button_class_init"));
  return(fun(c, e));
} 

void
S_gtk_button_box_class_init(GtkButtonBoxClass * c, SEXP e)
{
  static void (*fun)(GtkButtonBoxClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkButtonBoxClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_button_box_class_init"));
  return(fun(c, e));
} 

void
S_gtk_calendar_class_init(GtkCalendarClass * c, SEXP e)
{
  static void (*fun)(GtkCalendarClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkCalendarClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_calendar_class_init"));
  return(fun(c, e));
} 

void
S_gtk_cell_renderer_class_init(GtkCellRendererClass * c, SEXP e)
{
  static void (*fun)(GtkCellRendererClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkCellRendererClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_cell_renderer_class_init"));
  return(fun(c, e));
} 

void
S_gtk_cell_renderer_combo_class_init(GtkCellRendererComboClass * c, SEXP e)
{
  static void (*fun)(GtkCellRendererComboClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkCellRendererComboClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_cell_renderer_combo_class_init"));
  return(fun(c, e));
} 

void
S_gtk_cell_renderer_pixbuf_class_init(GtkCellRendererPixbufClass * c, SEXP e)
{
  static void (*fun)(GtkCellRendererPixbufClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkCellRendererPixbufClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_cell_renderer_pixbuf_class_init"));
  return(fun(c, e));
} 

void
S_gtk_cell_renderer_progress_class_init(GtkCellRendererProgressClass * c, SEXP e)
{
  static void (*fun)(GtkCellRendererProgressClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkCellRendererProgressClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_cell_renderer_progress_class_init"));
  return(fun(c, e));
} 

void
S_gtk_cell_renderer_text_class_init(GtkCellRendererTextClass * c, SEXP e)
{
  static void (*fun)(GtkCellRendererTextClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkCellRendererTextClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_cell_renderer_text_class_init"));
  return(fun(c, e));
} 

void
S_gtk_cell_renderer_toggle_class_init(GtkCellRendererToggleClass * c, SEXP e)
{
  static void (*fun)(GtkCellRendererToggleClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkCellRendererToggleClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_cell_renderer_toggle_class_init"));
  return(fun(c, e));
} 

void
S_gtk_cell_view_class_init(GtkCellViewClass * c, SEXP e)
{
  static void (*fun)(GtkCellViewClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkCellViewClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_cell_view_class_init"));
  return(fun(c, e));
} 

void
S_gtk_check_button_class_init(GtkCheckButtonClass * c, SEXP e)
{
  static void (*fun)(GtkCheckButtonClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkCheckButtonClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_check_button_class_init"));
  return(fun(c, e));
} 

void
S_gtk_check_menu_item_class_init(GtkCheckMenuItemClass * c, SEXP e)
{
  static void (*fun)(GtkCheckMenuItemClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkCheckMenuItemClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_check_menu_item_class_init"));
  return(fun(c, e));
} 

void
S_gtk_clist_class_init(GtkCListClass * c, SEXP e)
{
  static void (*fun)(GtkCListClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkCListClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_clist_class_init"));
  return(fun(c, e));
} 

void
S_gtk_color_button_class_init(GtkColorButtonClass * c, SEXP e)
{
  static void (*fun)(GtkColorButtonClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkColorButtonClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_color_button_class_init"));
  return(fun(c, e));
} 

void
S_gtk_color_selection_class_init(GtkColorSelectionClass * c, SEXP e)
{
  static void (*fun)(GtkColorSelectionClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkColorSelectionClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_color_selection_class_init"));
  return(fun(c, e));
} 

void
S_gtk_color_selection_dialog_class_init(GtkColorSelectionDialogClass * c, SEXP e)
{
  static void (*fun)(GtkColorSelectionDialogClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkColorSelectionDialogClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_color_selection_dialog_class_init"));
  return(fun(c, e));
} 

void
S_gtk_combo_class_init(GtkComboClass * c, SEXP e)
{
  static void (*fun)(GtkComboClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkComboClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_combo_class_init"));
  return(fun(c, e));
} 

void
S_gtk_combo_box_class_init(GtkComboBoxClass * c, SEXP e)
{
  static void (*fun)(GtkComboBoxClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkComboBoxClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_combo_box_class_init"));
  return(fun(c, e));
} 

void
S_gtk_combo_box_entry_class_init(GtkComboBoxEntryClass * c, SEXP e)
{
  static void (*fun)(GtkComboBoxEntryClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkComboBoxEntryClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_combo_box_entry_class_init"));
  return(fun(c, e));
} 

void
S_gtk_container_class_init(GtkContainerClass * c, SEXP e)
{
  static void (*fun)(GtkContainerClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkContainerClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_container_class_init"));
  return(fun(c, e));
} 

void
S_gtk_ctree_class_init(GtkCTreeClass * c, SEXP e)
{
  static void (*fun)(GtkCTreeClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkCTreeClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_ctree_class_init"));
  return(fun(c, e));
} 

void
S_gtk_curve_class_init(GtkCurveClass * c, SEXP e)
{
  static void (*fun)(GtkCurveClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkCurveClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_curve_class_init"));
  return(fun(c, e));
} 

void
S_gtk_dialog_class_init(GtkDialogClass * c, SEXP e)
{
  static void (*fun)(GtkDialogClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkDialogClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_dialog_class_init"));
  return(fun(c, e));
} 

void
S_gtk_drawing_area_class_init(GtkDrawingAreaClass * c, SEXP e)
{
  static void (*fun)(GtkDrawingAreaClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkDrawingAreaClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_drawing_area_class_init"));
  return(fun(c, e));
} 

void
S_gtk_entry_class_init(GtkEntryClass * c, SEXP e)
{
  static void (*fun)(GtkEntryClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkEntryClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_entry_class_init"));
  return(fun(c, e));
} 

void
S_gtk_entry_completion_class_init(GtkEntryCompletionClass * c, SEXP e)
{
  static void (*fun)(GtkEntryCompletionClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkEntryCompletionClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_entry_completion_class_init"));
  return(fun(c, e));
} 

void
S_gtk_event_box_class_init(GtkEventBoxClass * c, SEXP e)
{
  static void (*fun)(GtkEventBoxClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkEventBoxClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_event_box_class_init"));
  return(fun(c, e));
} 

void
S_gtk_expander_class_init(GtkExpanderClass * c, SEXP e)
{
  static void (*fun)(GtkExpanderClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkExpanderClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_expander_class_init"));
  return(fun(c, e));
} 

void
S_gtk_file_chooser_button_class_init(GtkFileChooserButtonClass * c, SEXP e)
{
  static void (*fun)(GtkFileChooserButtonClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkFileChooserButtonClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_file_chooser_button_class_init"));
  return(fun(c, e));
} 

void
S_gtk_file_chooser_dialog_class_init(GtkFileChooserDialogClass * c, SEXP e)
{
  static void (*fun)(GtkFileChooserDialogClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkFileChooserDialogClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_file_chooser_dialog_class_init"));
  return(fun(c, e));
} 

void
S_gtk_file_chooser_widget_class_init(GtkFileChooserWidgetClass * c, SEXP e)
{
  static void (*fun)(GtkFileChooserWidgetClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkFileChooserWidgetClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_file_chooser_widget_class_init"));
  return(fun(c, e));
} 

void
S_gtk_file_selection_class_init(GtkFileSelectionClass * c, SEXP e)
{
  static void (*fun)(GtkFileSelectionClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkFileSelectionClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_file_selection_class_init"));
  return(fun(c, e));
} 

void
S_gtk_fixed_class_init(GtkFixedClass * c, SEXP e)
{
  static void (*fun)(GtkFixedClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkFixedClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_fixed_class_init"));
  return(fun(c, e));
} 

void
S_gtk_font_button_class_init(GtkFontButtonClass * c, SEXP e)
{
  static void (*fun)(GtkFontButtonClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkFontButtonClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_font_button_class_init"));
  return(fun(c, e));
} 

void
S_gtk_font_selection_class_init(GtkFontSelectionClass * c, SEXP e)
{
  static void (*fun)(GtkFontSelectionClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkFontSelectionClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_font_selection_class_init"));
  return(fun(c, e));
} 

void
S_gtk_font_selection_dialog_class_init(GtkFontSelectionDialogClass * c, SEXP e)
{
  static void (*fun)(GtkFontSelectionDialogClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkFontSelectionDialogClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_font_selection_dialog_class_init"));
  return(fun(c, e));
} 

void
S_gtk_frame_class_init(GtkFrameClass * c, SEXP e)
{
  static void (*fun)(GtkFrameClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkFrameClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_frame_class_init"));
  return(fun(c, e));
} 

void
S_gtk_gamma_curve_class_init(GtkGammaCurveClass * c, SEXP e)
{
  static void (*fun)(GtkGammaCurveClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkGammaCurveClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_gamma_curve_class_init"));
  return(fun(c, e));
} 

void
S_gtk_handle_box_class_init(GtkHandleBoxClass * c, SEXP e)
{
  static void (*fun)(GtkHandleBoxClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkHandleBoxClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_handle_box_class_init"));
  return(fun(c, e));
} 

void
S_gtk_hbox_class_init(GtkHBoxClass * c, SEXP e)
{
  static void (*fun)(GtkHBoxClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkHBoxClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_hbox_class_init"));
  return(fun(c, e));
} 

void
S_gtk_hbutton_box_class_init(GtkHButtonBoxClass * c, SEXP e)
{
  static void (*fun)(GtkHButtonBoxClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkHButtonBoxClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_hbutton_box_class_init"));
  return(fun(c, e));
} 

void
S_gtk_hpaned_class_init(GtkHPanedClass * c, SEXP e)
{
  static void (*fun)(GtkHPanedClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkHPanedClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_hpaned_class_init"));
  return(fun(c, e));
} 

void
S_gtk_hruler_class_init(GtkHRulerClass * c, SEXP e)
{
  static void (*fun)(GtkHRulerClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkHRulerClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_hruler_class_init"));
  return(fun(c, e));
} 

void
S_gtk_hscale_class_init(GtkHScaleClass * c, SEXP e)
{
  static void (*fun)(GtkHScaleClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkHScaleClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_hscale_class_init"));
  return(fun(c, e));
} 

void
S_gtk_hscrollbar_class_init(GtkHScrollbarClass * c, SEXP e)
{
  static void (*fun)(GtkHScrollbarClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkHScrollbarClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_hscrollbar_class_init"));
  return(fun(c, e));
} 

void
S_gtk_hseparator_class_init(GtkHSeparatorClass * c, SEXP e)
{
  static void (*fun)(GtkHSeparatorClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkHSeparatorClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_hseparator_class_init"));
  return(fun(c, e));
} 

void
S_gtk_icon_factory_class_init(GtkIconFactoryClass * c, SEXP e)
{
  static void (*fun)(GtkIconFactoryClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkIconFactoryClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_icon_factory_class_init"));
  return(fun(c, e));
} 

void
S_gtk_icon_theme_class_init(GtkIconThemeClass * c, SEXP e)
{
  static void (*fun)(GtkIconThemeClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkIconThemeClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_icon_theme_class_init"));
  return(fun(c, e));
} 

void
S_gtk_icon_view_class_init(GtkIconViewClass * c, SEXP e)
{
  static void (*fun)(GtkIconViewClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkIconViewClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_icon_view_class_init"));
  return(fun(c, e));
} 

void
S_gtk_image_class_init(GtkImageClass * c, SEXP e)
{
  static void (*fun)(GtkImageClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkImageClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_image_class_init"));
  return(fun(c, e));
} 

void
S_gtk_image_menu_item_class_init(GtkImageMenuItemClass * c, SEXP e)
{
  static void (*fun)(GtkImageMenuItemClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkImageMenuItemClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_image_menu_item_class_init"));
  return(fun(c, e));
} 

void
S_gtk_imcontext_class_init(GtkIMContextClass * c, SEXP e)
{
  static void (*fun)(GtkIMContextClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkIMContextClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_imcontext_class_init"));
  return(fun(c, e));
} 

void
S_gtk_imcontext_simple_class_init(GtkIMContextSimpleClass * c, SEXP e)
{
  static void (*fun)(GtkIMContextSimpleClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkIMContextSimpleClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_imcontext_simple_class_init"));
  return(fun(c, e));
} 

void
S_gtk_immulticontext_class_init(GtkIMMulticontextClass * c, SEXP e)
{
  static void (*fun)(GtkIMMulticontextClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkIMMulticontextClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_immulticontext_class_init"));
  return(fun(c, e));
} 

void
S_gtk_input_dialog_class_init(GtkInputDialogClass * c, SEXP e)
{
  static void (*fun)(GtkInputDialogClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkInputDialogClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_input_dialog_class_init"));
  return(fun(c, e));
} 

void
S_gtk_invisible_class_init(GtkInvisibleClass * c, SEXP e)
{
  static void (*fun)(GtkInvisibleClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkInvisibleClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_invisible_class_init"));
  return(fun(c, e));
} 

void
S_gtk_item_class_init(GtkItemClass * c, SEXP e)
{
  static void (*fun)(GtkItemClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkItemClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_item_class_init"));
  return(fun(c, e));
} 

void
S_gtk_item_factory_class_init(GtkItemFactoryClass * c, SEXP e)
{
  static void (*fun)(GtkItemFactoryClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkItemFactoryClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_item_factory_class_init"));
  return(fun(c, e));
} 

void
S_gtk_label_class_init(GtkLabelClass * c, SEXP e)
{
  static void (*fun)(GtkLabelClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkLabelClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_label_class_init"));
  return(fun(c, e));
} 

void
S_gtk_layout_class_init(GtkLayoutClass * c, SEXP e)
{
  static void (*fun)(GtkLayoutClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkLayoutClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_layout_class_init"));
  return(fun(c, e));
} 

void
S_gtk_list_class_init(GtkListClass * c, SEXP e)
{
  static void (*fun)(GtkListClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkListClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_list_class_init"));
  return(fun(c, e));
} 

void
S_gtk_list_item_class_init(GtkListItemClass * c, SEXP e)
{
  static void (*fun)(GtkListItemClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkListItemClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_list_item_class_init"));
  return(fun(c, e));
} 

void
S_gtk_list_store_class_init(GtkListStoreClass * c, SEXP e)
{
  static void (*fun)(GtkListStoreClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkListStoreClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_list_store_class_init"));
  return(fun(c, e));
} 

void
S_gtk_menu_class_init(GtkMenuClass * c, SEXP e)
{
  static void (*fun)(GtkMenuClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkMenuClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_menu_class_init"));
  return(fun(c, e));
} 

void
S_gtk_menu_bar_class_init(GtkMenuBarClass * c, SEXP e)
{
  static void (*fun)(GtkMenuBarClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkMenuBarClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_menu_bar_class_init"));
  return(fun(c, e));
} 

void
S_gtk_menu_item_class_init(GtkMenuItemClass * c, SEXP e)
{
  static void (*fun)(GtkMenuItemClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkMenuItemClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_menu_item_class_init"));
  return(fun(c, e));
} 

void
S_gtk_menu_shell_class_init(GtkMenuShellClass * c, SEXP e)
{
  static void (*fun)(GtkMenuShellClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkMenuShellClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_menu_shell_class_init"));
  return(fun(c, e));
} 

void
S_gtk_menu_tool_button_class_init(GtkMenuToolButtonClass * c, SEXP e)
{
  static void (*fun)(GtkMenuToolButtonClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkMenuToolButtonClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_menu_tool_button_class_init"));
  return(fun(c, e));
} 

void
S_gtk_message_dialog_class_init(GtkMessageDialogClass * c, SEXP e)
{
  static void (*fun)(GtkMessageDialogClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkMessageDialogClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_message_dialog_class_init"));
  return(fun(c, e));
} 

void
S_gtk_misc_class_init(GtkMiscClass * c, SEXP e)
{
  static void (*fun)(GtkMiscClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkMiscClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_misc_class_init"));
  return(fun(c, e));
} 

void
S_gtk_notebook_class_init(GtkNotebookClass * c, SEXP e)
{
  static void (*fun)(GtkNotebookClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkNotebookClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_notebook_class_init"));
  return(fun(c, e));
} 

void
S_gtk_object_class_init(GtkObjectClass * c, SEXP e)
{
  static void (*fun)(GtkObjectClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkObjectClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_object_class_init"));
  return(fun(c, e));
} 

void
S_gtk_old_editable_class_init(GtkOldEditableClass * c, SEXP e)
{
  static void (*fun)(GtkOldEditableClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkOldEditableClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_old_editable_class_init"));
  return(fun(c, e));
} 

void
S_gtk_option_menu_class_init(GtkOptionMenuClass * c, SEXP e)
{
  static void (*fun)(GtkOptionMenuClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkOptionMenuClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_option_menu_class_init"));
  return(fun(c, e));
} 

void
S_gtk_paned_class_init(GtkPanedClass * c, SEXP e)
{
  static void (*fun)(GtkPanedClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkPanedClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_paned_class_init"));
  return(fun(c, e));
} 

void
S_gtk_pixmap_class_init(GtkPixmapClass * c, SEXP e)
{
  static void (*fun)(GtkPixmapClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkPixmapClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_pixmap_class_init"));
  return(fun(c, e));
} 

void
S_gtk_plug_class_init(GtkPlugClass * c, SEXP e)
{
  static void (*fun)(GtkPlugClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkPlugClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_plug_class_init"));
  return(fun(c, e));
} 

void
S_gtk_preview_class_init(GtkPreviewClass * c, SEXP e)
{
  static void (*fun)(GtkPreviewClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkPreviewClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_preview_class_init"));
  return(fun(c, e));
} 

void
S_gtk_progress_class_init(GtkProgressClass * c, SEXP e)
{
  static void (*fun)(GtkProgressClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkProgressClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_progress_class_init"));
  return(fun(c, e));
} 

void
S_gtk_progress_bar_class_init(GtkProgressBarClass * c, SEXP e)
{
  static void (*fun)(GtkProgressBarClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkProgressBarClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_progress_bar_class_init"));
  return(fun(c, e));
} 

void
S_gtk_radio_action_class_init(GtkRadioActionClass * c, SEXP e)
{
  static void (*fun)(GtkRadioActionClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkRadioActionClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_radio_action_class_init"));
  return(fun(c, e));
} 

void
S_gtk_radio_button_class_init(GtkRadioButtonClass * c, SEXP e)
{
  static void (*fun)(GtkRadioButtonClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkRadioButtonClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_radio_button_class_init"));
  return(fun(c, e));
} 

void
S_gtk_radio_menu_item_class_init(GtkRadioMenuItemClass * c, SEXP e)
{
  static void (*fun)(GtkRadioMenuItemClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkRadioMenuItemClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_radio_menu_item_class_init"));
  return(fun(c, e));
} 

void
S_gtk_radio_tool_button_class_init(GtkRadioToolButtonClass * c, SEXP e)
{
  static void (*fun)(GtkRadioToolButtonClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkRadioToolButtonClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_radio_tool_button_class_init"));
  return(fun(c, e));
} 

void
S_gtk_range_class_init(GtkRangeClass * c, SEXP e)
{
  static void (*fun)(GtkRangeClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkRangeClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_range_class_init"));
  return(fun(c, e));
} 

void
S_gtk_rc_style_class_init(GtkRcStyleClass * c, SEXP e)
{
  static void (*fun)(GtkRcStyleClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkRcStyleClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_rc_style_class_init"));
  return(fun(c, e));
} 

void
S_gtk_ruler_class_init(GtkRulerClass * c, SEXP e)
{
  static void (*fun)(GtkRulerClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkRulerClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_ruler_class_init"));
  return(fun(c, e));
} 

void
S_gtk_scale_class_init(GtkScaleClass * c, SEXP e)
{
  static void (*fun)(GtkScaleClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkScaleClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_scale_class_init"));
  return(fun(c, e));
} 

void
S_gtk_scrollbar_class_init(GtkScrollbarClass * c, SEXP e)
{
  static void (*fun)(GtkScrollbarClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkScrollbarClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_scrollbar_class_init"));
  return(fun(c, e));
} 

void
S_gtk_scrolled_window_class_init(GtkScrolledWindowClass * c, SEXP e)
{
  static void (*fun)(GtkScrolledWindowClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkScrolledWindowClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_scrolled_window_class_init"));
  return(fun(c, e));
} 

void
S_gtk_separator_class_init(GtkSeparatorClass * c, SEXP e)
{
  static void (*fun)(GtkSeparatorClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkSeparatorClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_separator_class_init"));
  return(fun(c, e));
} 

void
S_gtk_separator_menu_item_class_init(GtkSeparatorMenuItemClass * c, SEXP e)
{
  static void (*fun)(GtkSeparatorMenuItemClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkSeparatorMenuItemClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_separator_menu_item_class_init"));
  return(fun(c, e));
} 

void
S_gtk_separator_tool_item_class_init(GtkSeparatorToolItemClass * c, SEXP e)
{
  static void (*fun)(GtkSeparatorToolItemClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkSeparatorToolItemClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_separator_tool_item_class_init"));
  return(fun(c, e));
} 

void
S_gtk_settings_class_init(GtkSettingsClass * c, SEXP e)
{
  static void (*fun)(GtkSettingsClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkSettingsClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_settings_class_init"));
  return(fun(c, e));
} 

void
S_gtk_size_group_class_init(GtkSizeGroupClass * c, SEXP e)
{
  static void (*fun)(GtkSizeGroupClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkSizeGroupClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_size_group_class_init"));
  return(fun(c, e));
} 

void
S_gtk_socket_class_init(GtkSocketClass * c, SEXP e)
{
  static void (*fun)(GtkSocketClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkSocketClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_socket_class_init"));
  return(fun(c, e));
} 

void
S_gtk_spin_button_class_init(GtkSpinButtonClass * c, SEXP e)
{
  static void (*fun)(GtkSpinButtonClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkSpinButtonClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_spin_button_class_init"));
  return(fun(c, e));
} 

void
S_gtk_statusbar_class_init(GtkStatusbarClass * c, SEXP e)
{
  static void (*fun)(GtkStatusbarClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkStatusbarClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_statusbar_class_init"));
  return(fun(c, e));
} 

void
S_gtk_style_class_init(GtkStyleClass * c, SEXP e)
{
  static void (*fun)(GtkStyleClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkStyleClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_style_class_init"));
  return(fun(c, e));
} 

void
S_gtk_table_class_init(GtkTableClass * c, SEXP e)
{
  static void (*fun)(GtkTableClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkTableClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_table_class_init"));
  return(fun(c, e));
} 

void
S_gtk_tearoff_menu_item_class_init(GtkTearoffMenuItemClass * c, SEXP e)
{
  static void (*fun)(GtkTearoffMenuItemClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkTearoffMenuItemClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_tearoff_menu_item_class_init"));
  return(fun(c, e));
} 

void
S_gtk_text_buffer_class_init(GtkTextBufferClass * c, SEXP e)
{
  static void (*fun)(GtkTextBufferClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkTextBufferClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_text_buffer_class_init"));
  return(fun(c, e));
} 

void
S_gtk_text_child_anchor_class_init(GtkTextChildAnchorClass * c, SEXP e)
{
  static void (*fun)(GtkTextChildAnchorClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkTextChildAnchorClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_text_child_anchor_class_init"));
  return(fun(c, e));
} 

void
S_gtk_text_mark_class_init(GtkTextMarkClass * c, SEXP e)
{
  static void (*fun)(GtkTextMarkClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkTextMarkClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_text_mark_class_init"));
  return(fun(c, e));
} 

void
S_gtk_text_tag_class_init(GtkTextTagClass * c, SEXP e)
{
  static void (*fun)(GtkTextTagClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkTextTagClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_text_tag_class_init"));
  return(fun(c, e));
} 

void
S_gtk_text_tag_table_class_init(GtkTextTagTableClass * c, SEXP e)
{
  static void (*fun)(GtkTextTagTableClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkTextTagTableClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_text_tag_table_class_init"));
  return(fun(c, e));
} 

void
S_gtk_text_view_class_init(GtkTextViewClass * c, SEXP e)
{
  static void (*fun)(GtkTextViewClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkTextViewClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_text_view_class_init"));
  return(fun(c, e));
} 

void
S_gtk_tips_query_class_init(GtkTipsQueryClass * c, SEXP e)
{
  static void (*fun)(GtkTipsQueryClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkTipsQueryClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_tips_query_class_init"));
  return(fun(c, e));
} 

void
S_gtk_toggle_action_class_init(GtkToggleActionClass * c, SEXP e)
{
  static void (*fun)(GtkToggleActionClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkToggleActionClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_toggle_action_class_init"));
  return(fun(c, e));
} 

void
S_gtk_toggle_button_class_init(GtkToggleButtonClass * c, SEXP e)
{
  static void (*fun)(GtkToggleButtonClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkToggleButtonClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_toggle_button_class_init"));
  return(fun(c, e));
} 

void
S_gtk_toggle_tool_button_class_init(GtkToggleToolButtonClass * c, SEXP e)
{
  static void (*fun)(GtkToggleToolButtonClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkToggleToolButtonClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_toggle_tool_button_class_init"));
  return(fun(c, e));
} 

void
S_gtk_toolbar_class_init(GtkToolbarClass * c, SEXP e)
{
  static void (*fun)(GtkToolbarClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkToolbarClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_toolbar_class_init"));
  return(fun(c, e));
} 

void
S_gtk_tool_button_class_init(GtkToolButtonClass * c, SEXP e)
{
  static void (*fun)(GtkToolButtonClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkToolButtonClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_tool_button_class_init"));
  return(fun(c, e));
} 

void
S_gtk_tool_item_class_init(GtkToolItemClass * c, SEXP e)
{
  static void (*fun)(GtkToolItemClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkToolItemClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_tool_item_class_init"));
  return(fun(c, e));
} 

void
S_gtk_tooltips_class_init(GtkTooltipsClass * c, SEXP e)
{
  static void (*fun)(GtkTooltipsClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkTooltipsClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_tooltips_class_init"));
  return(fun(c, e));
} 

void
S_gtk_tree_model_filter_class_init(GtkTreeModelFilterClass * c, SEXP e)
{
  static void (*fun)(GtkTreeModelFilterClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkTreeModelFilterClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_tree_model_filter_class_init"));
  return(fun(c, e));
} 

void
S_gtk_tree_model_sort_class_init(GtkTreeModelSortClass * c, SEXP e)
{
  static void (*fun)(GtkTreeModelSortClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkTreeModelSortClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_tree_model_sort_class_init"));
  return(fun(c, e));
} 

void
S_gtk_tree_selection_class_init(GtkTreeSelectionClass * c, SEXP e)
{
  static void (*fun)(GtkTreeSelectionClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkTreeSelectionClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_tree_selection_class_init"));
  return(fun(c, e));
} 

void
S_gtk_tree_store_class_init(GtkTreeStoreClass * c, SEXP e)
{
  static void (*fun)(GtkTreeStoreClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkTreeStoreClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_tree_store_class_init"));
  return(fun(c, e));
} 

void
S_gtk_tree_view_class_init(GtkTreeViewClass * c, SEXP e)
{
  static void (*fun)(GtkTreeViewClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkTreeViewClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_tree_view_class_init"));
  return(fun(c, e));
} 

void
S_gtk_tree_view_column_class_init(GtkTreeViewColumnClass * c, SEXP e)
{
  static void (*fun)(GtkTreeViewColumnClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkTreeViewColumnClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_tree_view_column_class_init"));
  return(fun(c, e));
} 

void
S_gtk_uimanager_class_init(GtkUIManagerClass * c, SEXP e)
{
  static void (*fun)(GtkUIManagerClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkUIManagerClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_uimanager_class_init"));
  return(fun(c, e));
} 

void
S_gtk_vbox_class_init(GtkVBoxClass * c, SEXP e)
{
  static void (*fun)(GtkVBoxClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkVBoxClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_vbox_class_init"));
  return(fun(c, e));
} 

void
S_gtk_vbutton_box_class_init(GtkVButtonBoxClass * c, SEXP e)
{
  static void (*fun)(GtkVButtonBoxClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkVButtonBoxClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_vbutton_box_class_init"));
  return(fun(c, e));
} 

void
S_gtk_viewport_class_init(GtkViewportClass * c, SEXP e)
{
  static void (*fun)(GtkViewportClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkViewportClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_viewport_class_init"));
  return(fun(c, e));
} 

void
S_gtk_vpaned_class_init(GtkVPanedClass * c, SEXP e)
{
  static void (*fun)(GtkVPanedClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkVPanedClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_vpaned_class_init"));
  return(fun(c, e));
} 

void
S_gtk_vruler_class_init(GtkVRulerClass * c, SEXP e)
{
  static void (*fun)(GtkVRulerClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkVRulerClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_vruler_class_init"));
  return(fun(c, e));
} 

void
S_gtk_vscale_class_init(GtkVScaleClass * c, SEXP e)
{
  static void (*fun)(GtkVScaleClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkVScaleClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_vscale_class_init"));
  return(fun(c, e));
} 

void
S_gtk_vscrollbar_class_init(GtkVScrollbarClass * c, SEXP e)
{
  static void (*fun)(GtkVScrollbarClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkVScrollbarClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_vscrollbar_class_init"));
  return(fun(c, e));
} 

void
S_gtk_vseparator_class_init(GtkVSeparatorClass * c, SEXP e)
{
  static void (*fun)(GtkVSeparatorClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkVSeparatorClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_vseparator_class_init"));
  return(fun(c, e));
} 

void
S_gtk_widget_class_init(GtkWidgetClass * c, SEXP e)
{
  static void (*fun)(GtkWidgetClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkWidgetClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_widget_class_init"));
  return(fun(c, e));
} 

void
S_gtk_window_class_init(GtkWindowClass * c, SEXP e)
{
  static void (*fun)(GtkWindowClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkWindowClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_window_class_init"));
  return(fun(c, e));
} 

void
S_gtk_window_group_class_init(GtkWindowGroupClass * c, SEXP e)
{
  static void (*fun)(GtkWindowGroupClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkWindowGroupClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_window_group_class_init"));
  return(fun(c, e));
} 

#if GTK_CHECK_VERSION(2, 10, 0)
void
S_gtk_cell_renderer_accel_class_init(GtkCellRendererAccelClass * c, SEXP e)
{
  static void (*fun)(GtkCellRendererAccelClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkCellRendererAccelClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_cell_renderer_accel_class_init"));
  return(fun(c, e));
}
#endif 

#if GTK_CHECK_VERSION(2, 10, 0)
void
S_gtk_cell_renderer_spin_class_init(GtkCellRendererSpinClass * c, SEXP e)
{
  static void (*fun)(GtkCellRendererSpinClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkCellRendererSpinClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_cell_renderer_spin_class_init"));
  return(fun(c, e));
}
#endif 

#if GTK_CHECK_VERSION(2, 10, 0)
void
S_gtk_print_operation_class_init(GtkPrintOperationClass * c, SEXP e)
{
  static void (*fun)(GtkPrintOperationClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkPrintOperationClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_print_operation_class_init"));
  return(fun(c, e));
}
#endif 

#if GTK_CHECK_VERSION(2, 10, 0)
void
S_gtk_recent_manager_class_init(GtkRecentManagerClass * c, SEXP e)
{
  static void (*fun)(GtkRecentManagerClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkRecentManagerClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_recent_manager_class_init"));
  return(fun(c, e));
}
#endif 

#if GTK_CHECK_VERSION(2, 10, 0)
void
S_gtk_status_icon_class_init(GtkStatusIconClass * c, SEXP e)
{
  static void (*fun)(GtkStatusIconClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkStatusIconClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_status_icon_class_init"));
  return(fun(c, e));
}
#endif 

#if GTK_CHECK_VERSION(2, 10, 0)
void
S_gtk_recent_chooser_menu_class_init(GtkRecentChooserMenuClass * c, SEXP e)
{
  static void (*fun)(GtkRecentChooserMenuClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkRecentChooserMenuClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_recent_chooser_menu_class_init"));
  return(fun(c, e));
}
#endif 

#if GTK_CHECK_VERSION(2, 10, 0)
void
S_gtk_link_button_class_init(GtkLinkButtonClass * c, SEXP e)
{
  static void (*fun)(GtkLinkButtonClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkLinkButtonClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_link_button_class_init"));
  return(fun(c, e));
}
#endif 

#if GTK_CHECK_VERSION(2, 10, 0)
void
S_gtk_recent_chooser_widget_class_init(GtkRecentChooserWidgetClass * c, SEXP e)
{
  static void (*fun)(GtkRecentChooserWidgetClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkRecentChooserWidgetClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_recent_chooser_widget_class_init"));
  return(fun(c, e));
}
#endif 

#if GTK_CHECK_VERSION(2, 10, 0)
void
S_gtk_recent_chooser_dialog_class_init(GtkRecentChooserDialogClass * c, SEXP e)
{
  static void (*fun)(GtkRecentChooserDialogClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkRecentChooserDialogClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_recent_chooser_dialog_class_init"));
  return(fun(c, e));
}
#endif 

#if GTK_CHECK_VERSION(2, 10, 0)
void
S_gtk_assistant_class_init(GtkAssistantClass * c, SEXP e)
{
  static void (*fun)(GtkAssistantClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkAssistantClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_assistant_class_init"));
  return(fun(c, e));
}
#endif 

#if GTK_CHECK_VERSION(2, 12, 0)
void
S_gtk_builder_class_init(GtkBuilderClass * c, SEXP e)
{
  static void (*fun)(GtkBuilderClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkBuilderClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_builder_class_init"));
  return(fun(c, e));
}
#endif 

#if GTK_CHECK_VERSION(2, 12, 0)
void
S_gtk_recent_action_class_init(GtkRecentActionClass * c, SEXP e)
{
  static void (*fun)(GtkRecentActionClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkRecentActionClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_recent_action_class_init"));
  return(fun(c, e));
}
#endif 

#if GTK_CHECK_VERSION(2, 12, 0)
void
S_gtk_scale_button_class_init(GtkScaleButtonClass * c, SEXP e)
{
  static void (*fun)(GtkScaleButtonClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkScaleButtonClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_scale_button_class_init"));
  return(fun(c, e));
}
#endif 

#if GTK_CHECK_VERSION(2, 12, 0)
void
S_gtk_volume_button_class_init(GtkVolumeButtonClass * c, SEXP e)
{
  static void (*fun)(GtkVolumeButtonClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkVolumeButtonClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_volume_button_class_init"));
  return(fun(c, e));
}
#endif 

#if GTK_CHECK_VERSION(2, 14, 0)
void
S_gtk_mount_operation_class_init(GtkMountOperationClass * c, SEXP e)
{
  static void (*fun)(GtkMountOperationClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkMountOperationClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_mount_operation_class_init"));
  return(fun(c, e));
}
#endif 

#if GTK_CHECK_VERSION(2, 18, 0)
void
S_gtk_entry_buffer_class_init(GtkEntryBufferClass * c, SEXP e)
{
  static void (*fun)(GtkEntryBufferClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkEntryBufferClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_entry_buffer_class_init"));
  return(fun(c, e));
}
#endif 

#if GTK_CHECK_VERSION(2, 18, 0)
void
S_gtk_info_bar_class_init(GtkInfoBarClass * c, SEXP e)
{
  static void (*fun)(GtkInfoBarClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkInfoBarClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_info_bar_class_init"));
  return(fun(c, e));
}
#endif 

#if GTK_CHECK_VERSION(2, 18, 0)
void
S_gtk_hsv_class_init(GtkHSVClass * c, SEXP e)
{
  static void (*fun)(GtkHSVClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkHSVClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_hsv_class_init"));
  return(fun(c, e));
}
#endif 

#if GTK_CHECK_VERSION(2, 20, 0)
void
S_gtk_tool_item_group_class_init(GtkToolItemGroupClass * c, SEXP e)
{
  static void (*fun)(GtkToolItemGroupClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkToolItemGroupClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_tool_item_group_class_init"));
  return(fun(c, e));
}
#endif 

#if GTK_CHECK_VERSION(2, 20, 0)
void
S_gtk_tool_palette_class_init(GtkToolPaletteClass * c, SEXP e)
{
  static void (*fun)(GtkToolPaletteClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkToolPaletteClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_tool_palette_class_init"));
  return(fun(c, e));
}
#endif 

#if GTK_CHECK_VERSION(2, 20, 0)
void
S_gtk_cell_renderer_spinner_class_init(GtkCellRendererSpinnerClass * c, SEXP e)
{
  static void (*fun)(GtkCellRendererSpinnerClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkCellRendererSpinnerClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_cell_renderer_spinner_class_init"));
  return(fun(c, e));
}
#endif 

#if GTK_CHECK_VERSION(2, 20, 0)
void
S_gtk_offscreen_window_class_init(GtkOffscreenWindowClass * c, SEXP e)
{
  static void (*fun)(GtkOffscreenWindowClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkOffscreenWindowClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_offscreen_window_class_init"));
  return(fun(c, e));
}
#endif 

#if GTK_CHECK_VERSION(2, 20, 0)
void
S_gtk_spinner_class_init(GtkSpinnerClass * c, SEXP e)
{
  static void (*fun)(GtkSpinnerClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkSpinnerClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_spinner_class_init"));
  return(fun(c, e));
}
#endif 

void
S_gtk_cell_editable_class_init(GtkCellEditableIface * c, SEXP e)
{
  static void (*fun)(GtkCellEditableIface *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkCellEditableIface *, SEXP))R_GetCCallable("RGtk2", "S_gtk_cell_editable_class_init"));
  return(fun(c, e));
} 

void
S_gtk_cell_layout_class_init(GtkCellLayoutIface * c, SEXP e)
{
  static void (*fun)(GtkCellLayoutIface *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkCellLayoutIface *, SEXP))R_GetCCallable("RGtk2", "S_gtk_cell_layout_class_init"));
  return(fun(c, e));
} 

void
S_gtk_editable_class_init(GtkEditableClass * c, SEXP e)
{
  static void (*fun)(GtkEditableClass *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkEditableClass *, SEXP))R_GetCCallable("RGtk2", "S_gtk_editable_class_init"));
  return(fun(c, e));
} 

void
S_gtk_tree_drag_dest_class_init(GtkTreeDragDestIface * c, SEXP e)
{
  static void (*fun)(GtkTreeDragDestIface *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkTreeDragDestIface *, SEXP))R_GetCCallable("RGtk2", "S_gtk_tree_drag_dest_class_init"));
  return(fun(c, e));
} 

void
S_gtk_tree_drag_source_class_init(GtkTreeDragSourceIface * c, SEXP e)
{
  static void (*fun)(GtkTreeDragSourceIface *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkTreeDragSourceIface *, SEXP))R_GetCCallable("RGtk2", "S_gtk_tree_drag_source_class_init"));
  return(fun(c, e));
} 

void
S_gtk_tree_model_class_init(GtkTreeModelIface * c, SEXP e)
{
  static void (*fun)(GtkTreeModelIface *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkTreeModelIface *, SEXP))R_GetCCallable("RGtk2", "S_gtk_tree_model_class_init"));
  return(fun(c, e));
} 

void
S_gtk_tree_sortable_class_init(GtkTreeSortableIface * c, SEXP e)
{
  static void (*fun)(GtkTreeSortableIface *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkTreeSortableIface *, SEXP))R_GetCCallable("RGtk2", "S_gtk_tree_sortable_class_init"));
  return(fun(c, e));
} 

#if GTK_CHECK_VERSION(2, 12, 0)
void
S_gtk_buildable_class_init(GtkBuildableIface * c, SEXP e)
{
  static void (*fun)(GtkBuildableIface *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkBuildableIface *, SEXP))R_GetCCallable("RGtk2", "S_gtk_buildable_class_init"));
  return(fun(c, e));
}
#endif 

#if GTK_CHECK_VERSION(2, 14, 0)
void
S_gtk_tool_shell_class_init(GtkToolShellIface * c, SEXP e)
{
  static void (*fun)(GtkToolShellIface *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkToolShellIface *, SEXP))R_GetCCallable("RGtk2", "S_gtk_tool_shell_class_init"));
  return(fun(c, e));
}
#endif 

#if GTK_CHECK_VERSION(2, 16, 0)
void
S_gtk_activatable_class_init(GtkActivatableIface * c, SEXP e)
{
  static void (*fun)(GtkActivatableIface *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkActivatableIface *, SEXP))R_GetCCallable("RGtk2", "S_gtk_activatable_class_init"));
  return(fun(c, e));
}
#endif 

#if GTK_CHECK_VERSION(2, 16, 0)
void
S_gtk_orientable_class_init(GtkOrientableIface * c, SEXP e)
{
  static void (*fun)(GtkOrientableIface *, SEXP) = NULL;
  if(!fun) fun = ((void (*)(GtkOrientableIface *, SEXP))R_GetCCallable("RGtk2", "S_gtk_orientable_class_init"));
  return(fun(c, e));
}
#endif 

